<div class="fpd-browser-alert">
	<p><strong>Your browser does not support this product designer.</strong><br />Please update your browser or download one of these browsers:</p>
	<span><a href="http://www.mozilla.org/firefox/new/" title="Download Firefox" class="firefox">Firefox</a><a href="http://www.google.com/Chrome" title="Download Chrome" class="chrome">Chrome</a><a href="http://www.opera.com/download/" title="Download Opera" class="opera">Opera</a></span>
</div>