
<input type="button" id="slideshow-insert-video-slide" class="button" value="<?php _e('Video slide', 'slideshow-plugin'); ?>" />
